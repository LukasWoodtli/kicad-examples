# Design an RP2040 board with KiCad

Example code and assets for Design an RP2040 board with KiCad from Raspberry Pi Press
