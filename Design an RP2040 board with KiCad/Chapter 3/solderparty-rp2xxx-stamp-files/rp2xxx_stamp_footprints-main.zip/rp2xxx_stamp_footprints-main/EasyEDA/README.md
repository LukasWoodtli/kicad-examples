The symbols and footprints are available in the EasyEDA library, just search for "RP2xxx", or use this link:

https://u.easyeda.com/search?wd=rp2xxx&indextype=components

We have also created and shared a project that includes all the symbols and footprints so that they can be copied over:

https://oshwlab.com/arturo182/stamp_gallery
