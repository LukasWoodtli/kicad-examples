# RP2xxx Stamp Footprints and Symbols

This repo contains symbols and footprints for the RP2xxx (RP2040 and RP2350) Stamps for various CAD programs.

The library in Eagle/ can also be used with Fusion 360.

If you notice any issues with the footprints (we are mainly KiCad users), or want to port the footprint to a new program, PRs are very welcome :)
